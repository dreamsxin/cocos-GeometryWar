/*
 * @Autor: Rao
 * @Date: 2021-05-16 10:24:27
 * @LastEditors: Rao
 * @LastEditTime: 2021-05-16 11:31:52
 * @Description: 
 */

import GameComponent from "../GameComponent";
import UIMgr from "../Manager/UIMgr";
import EventMgr from "../Manager/EventMgr";

const {ccclass, property} = cc._decorator;

@ccclass
export default class GameOver extends GameComponent {

    

    onLoad () {
        GameComponent.prototype.onLoad.call(this);
        //this.uiNodes['_btnTrayAgain'].on('click', this.trayAgain, this);
        this.uiNodes['_btnReturnMenu'].on('click', this.ReturnMenu, this);
    }


    trayAgain() {
        // 无法得知改返回哪个模式的场景
        //EventMgr.getInstance().EventDispatcher('');
    }

    ReturnMenu() {
        EventMgr.getInstance().EventDispatcher('');
    }
}
