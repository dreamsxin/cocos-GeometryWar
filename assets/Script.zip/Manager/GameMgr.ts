/*
 * @Autor: Rao
 * @Date: 2021-04-06 13:29:22
 * @LastEditors: Rao
 * @LastEditTime: 2021-05-16 11:35:19
 * @Description:'
 */

import GameComponent from "../GameComponent";
import UIMgr from "./UIMgr";

const {ccclass, property} = cc._decorator;

@ccclass
export default class GameMgr extends GameComponent {

    onLoad () {
        GameComponent.prototype.onLoad.call(this);
        UIMgr.getInstance().openUINode(this.node, 'GameMenu');
    }

    listEvent() {
        return ['openRelaxMenu','openAdventureMenu', 'openRelaxScene', 'openAdventureScene', 'openPauseScene','callFuncObstacle','openGameMenu'];
    }
    onEvent(event:string, params) {
        if(event.startsWith('open')) {
            let parentNode = params ? params : this.node;
            UIMgr.getInstance().openUINode(parentNode, event.substr(4));
        }
        else if (event.startsWith('callFunc')) {
            let path = 'Canvas/Game/'+params.scene+'/'+params.nodeName;
            let node = cc.find(path);
            let ts:any = node.getComponent(params.tsName);
            let funcName = params.funcName;
            let func = ts.getFuncByName(funcName);
            func.call(ts, params.args);
        }
    }

    onDestroy () {
        GameComponent.prototype.removeEvent.call(this);
    }
}
