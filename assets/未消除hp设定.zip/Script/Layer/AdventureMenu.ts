/*
 * @Autor: Rao
 * @Date: 2021-05-01 12:10:32
 * @LastEditors: Rao
 * @LastEditTime: 2021-05-16 11:39:40
 * @Description:
 */

import GameComponent from "../GameComponent";
import UIMgr from "../Manager/UIMgr";
import EventMgr from "../Manager/EventMgr";


const {ccclass, property} = cc._decorator;

@ccclass
export default class AdventureMenu extends GameComponent {

    // LIFE-CYCLE CALLBACKS:

    onLoad () {
        GameComponent.prototype.onLoad.call(this);
        this.uiNodes['_btnStart'].on('click', this.enterAdventureGameScene, this);
        this.uiNodes['_btnReturn'].on('click', this.exitAdventureGameScene, this);
    }

    enterAdventureGameScene () {
        //UIMgr.getInstance().closeUINode(this.node);
        EventMgr.getInstance().EventDispatcher('openAdventureScene', {'curNode': this.node});
    }

    exitAdventureGameScene () {
        //UIMgr.getInstance().closeUINode(this.node);
        EventMgr.getInstance().EventDispatcher('openGameMenu', {'curNode': this.node});
    }
    
    onDestroy () {
        this.uiNodes['_btnStart'].off('click', this.enterAdventureGameScene, this);
        this.uiNodes['_btnReturn'].off('click', this.exitAdventureGameScene, this);
    }
}
