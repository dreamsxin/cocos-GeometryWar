/*
 * @Autor: Rao
 * @Date: 2021-04-07 13:28:04
 * @LastEditors: Rao
 * @LastEditTime: 2021-04-08 11:55:29
 * @Description: 
 */

import GameComponent from "../GameComponent";
import ResMgr from "./ResMgr";


const {ccclass, property} = cc._decorator;

@ccclass
export default class PlayerMgr {
   

}
