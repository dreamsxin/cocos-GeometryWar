/*
 * @Autor: Rao
 * @Date: 2021-04-21 22:42:31
 * @LastEditors: Rao
 * @LastEditTime: 2021-05-02 15:14:02
 * @Description: 
 */
// Learn TypeScript:
//  - https://docs.cocos.com/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html

import GameComponent from "../GameComponent";
import EventMgr from "../Manager/EventMgr";

const {ccclass, property} = cc._decorator;

@ccclass
export default class Money extends GameComponent {

    vel: number=350;
    isRelaxScene: boolean;

    onLoad () {
        this.isRelaxScene = this.node.parent.name === 'RelaxScene';
        if(this.isRelaxScene) {
            let posX = Math.ceil(Math.random()*680)+100;
            this.node.x = posX;
            this.node.y = 650;
        }
    }

    start () {

    }

    update (dt) {
        if(this.isRelaxScene) {
            this.node.y -= dt*this.vel;
        }
    }

    onCollisionEnter(other) {
        let colliName = other.node.group;
        if(colliName === 'ground') {
            this.node.destroy();
        }
        if (colliName === 'hero') {
            this.node.destroy();
        }
        if(colliName === 'rail') {
            this.vel=0;
        }
    }
}
